# 配置修改

配置文件路径： `SuperBizAgent/src/main/resources/application.yml`

按照《环境准备教程-项目配置》的步骤，修改配置文件



# 一键式启动

输入 `make help` 可以看到启动命令，建议使用 `make init` 一键启动

注意，在启动之前务必将配置文件中的api key填好。mcp端口也要填好（或者直接注释掉，走mock）

| ![](images/904ba2c2fe0c6ee036affb4c55258856.png) | ![](images/b5e5d6da991d447cb6ef4b719ca50bb7.png) |
| ------------------------------------------------ | ------------------------------------------------ |

